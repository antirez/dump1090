For information about using this software, please see:

  http://planeplotter.pbworks.com/Dump1090

David Taylor
2014-May-08